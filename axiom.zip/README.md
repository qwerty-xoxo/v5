![image](https://github.com/infdevv/Axiom/assets/133452064/4c170d9e-0a31-4a8f-bab1-f5a6b6cefd72)
# Axiom

A free ( BETA ) backendless unblocker. 

Features:

- In progress non-ultraviolet proxy
- Work in progress apps
- Can be deployed on static hosts
