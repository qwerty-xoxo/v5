![image](https://github.com/infdevv/Axiom/assets/133452064/4c170d9e-0a31-4a8f-bab1-f5a6b6cefd72)
# Axiom

A free ( BETA ) backendless unblocker. 

[![Run on Replit](https://binbashbanana.github.io/deploy-buttons/buttons/remade/replit.svg)](https://replit.com/github/infdevv/axiom)
[![Remix on Glitch](https://binbashbanana.github.io/deploy-buttons/buttons/remade/glitch.svg)](https://glitch.com/edit/#!/import/github/infdevv/axiom)
[![Deploy with Vercel](https://binbashbanana.github.io/deploy-buttons/buttons/remade/vercel.svg)](https://vercel.com/new/clone?repositoryurl=https://github.com/infdevv/axiom)
<a target="_blank" href="https://heroku.com/deploy/?template=https://github.com/interstellarnetwork/interstellar"><img alt="Deploy to Heroku" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/heroku.svg"></a>
<a target="_blank" href="https://app.koyeb.com/deploy?type=git&repository=github.com/infdevv/axiom"><img alt="Deploy to Koyeb" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/koyeb.svg"></a>
<a target="_blank" href="https://app.cyclic.sh/api/app/deploy/infdevv/axiom"><img alt="Deploy to Cyclic" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/cyclic.svg"></a>
[![Deploy to Netlify](https://binbashbanana.github.io/deploy-buttons/buttons/official/netlify.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/infdevv/axiom)

Features:

- In progress non-ultraviolet proxy
- Work in progress apps
- Can be deployed on static hosts
- Forced cloaking making links last longer
- 
If you have problems or suggestions for/with the site or deploying then check out our [Discord](https://discord.gg/Ub6zGw4RAC)
 